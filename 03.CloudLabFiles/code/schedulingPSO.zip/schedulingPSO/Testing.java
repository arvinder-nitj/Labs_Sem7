package schedulingPSO;

public class Testing

{
	public static void main(String[] args)
	{
		
		int a=10; int b=20; 
		int c=Math.min(a, b);
		System.out.println("value of c is :"+c);
		
	}
 
}

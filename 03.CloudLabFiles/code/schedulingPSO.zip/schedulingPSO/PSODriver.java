package schedulingPSO;

// main class of PSO

public class PSODriver {
	public static void main(String args[]) {
		new PSOProcess().execute();
	}
}
